﻿using System;

namespace newday_diamond_demo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello World!");
            Console.Write("Please enter a character: ");
            char.TryParse(Console.ReadLine().ToUpper(), out var midChar);

            PrintDiamond(midChar);

            Console.ReadLine();
        }

        static void PrintDiamond(char midChar)
        {
            var letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray();

            var letterNumber = Array.IndexOf(letters, midChar);

            if (letterNumber <= 0)
            {
                Console.Write("Please enter a character between A to Z: ");

                char.TryParse(Console.ReadLine().ToUpper(), out var middlieChar);

                PrintDiamond(middlieChar);
            }
            else if (letterNumber > 0)
            {
                var strArray = new string[52];
                // Print the top half of the diamond
                for (int i = 0; i <= letterNumber; i++)
                {
                    for (int j = 0; j < letterNumber - i; j++)
                        strArray[i] += " ";

                    strArray[i] += letters[i];

                    if (letters[i] != 'A')
                    {
                        for (int j = 0; j < 2 * i - 1; j++)
                            strArray[i] += " ";

                        strArray[i] += letters[i];
                    }

                    Console.WriteLine(strArray[i]);
                }

                // Print the bottom half of the diamond
                for (int i = letterNumber - 1; i >= 0; i--)
                    Console.WriteLine(strArray[i]);
            }
        }
    }
}
